# My wicked markdown

## This is from a file-input :)

{{plot}}

As above we do ...

{{select}}

Here's the dataset used...

{{}}
