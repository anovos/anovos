# Copyright 2020 StackHut Limited (trading as Datapane)
# SPDX-License-Identifier: Apache-2.0

import os

os.environ["DATAPANE_BY_DATAPANE"] = "true"
