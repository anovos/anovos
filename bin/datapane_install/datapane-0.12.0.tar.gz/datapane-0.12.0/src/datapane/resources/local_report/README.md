
## Notes

- `local-report-base.css|js` needs to be copied to this dir to enable local report saving
